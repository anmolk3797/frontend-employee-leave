export const ASYNC_ROUTES = {
    //---------------------Auth------------------//
    USER_LOGIN: "/login",
    USER_LOGOUT: "/logout",
    USER_TOKEN_REFRESH: "/login/refresh",
  
  
}



export const THUNK_STATUS = {
    LOADING: "loading",
    SUCCESS: "success",
    FAILED: "failed",
  };
export const ROUTE_NAME = {
    BASE:'/',
    DASHBOARD:'/',
    LOGIN:"/login",
    SIGNUP:"/signup",
    LEAVE_FORM:"/leaveform"
      
  };
  
  export const ROUTE_DEFINATION = {
    BASE: ROUTE_NAME.BASE,
   // CHANGE_PASSWORD : ROUTE_NAME.CHANGE_PASSWORD,
    DASHBOARD: ROUTE_NAME.DASHBOARD,
    LOGIN: ROUTE_NAME.LOGIN,
    SIGNUP:ROUTE_NAME.SIGNUP,
    LEAVE_FORM:ROUTE_NAME.LEAVE_FORM,
  
    
  };
  